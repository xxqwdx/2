package com.example.wagecalc;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;

import java.io.File;

/**
 * WebView 壳：加载 assets/index.html（计件计时工资计算器）
 *
 * 关键点：
 * 1. 通过 WebViewAssetLoader 以 https://appassets.androidplatform.net 域名加载本地资源，
 *    使页面拥有正常 origin，localStorage / IndexedDB 才能可靠持久化
 *    （file:// 协议下 origin 为 null，数据易丢失）。
 * 2. 必须开启 setDomStorageEnabled(true)，否则 localStorage 不生效；
 *    开启 setDatabaseEnabled(true)，IndexedDB 才能用（页面用它存附件图片）。
 * 3. 必须设置 WebChromeClient，否则 alert / confirm 不弹窗。
 * 4. 必须实现 onShowFileChooser，否则页面里的 <input type="file"> 点击毫无反应。
 */
public class MainActivity extends Activity {

    private static final int REQ_FILE_CHOOSER = 1001;

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private Uri cameraImageUri;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setTextZoom(100);

        // 用 WebViewClient 拦截请求，把 assets 映射到虚拟 https 域名下
        final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }
        });

        // WebChromeClient：既要保证 alert / confirm 能弹，也要接管文件选择
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view,
                                             ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                // 先释放上一次未完成的回调，避免选择器卡死
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                    filePathCallback = null;
                }
                filePathCallback = callback;
                cameraImageUri = null;

                // 相册 / 文件选择（支持多选）
                Intent contentIntent = new Intent(Intent.ACTION_GET_CONTENT);
                contentIntent.addCategory(Intent.CATEGORY_OPENABLE);
                contentIntent.setType("image/*");
                if (params != null && params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) {
                    contentIntent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                }

                Intent chooser = Intent.createChooser(contentIntent, "选择报表附件");

                // 额外加一个拍照入口
                Intent capture = buildCameraIntent();
                if (capture != null) {
                    chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{capture});
                }

                try {
                    startActivityForResult(chooser, REQ_FILE_CHOOSER);
                } catch (Exception e) {
                    filePathCallback = null;
                    cameraImageUri = null;
                    return false;
                }
                return true;
            }
        });

        // 隐藏滚动条，界面更接近原生
        webView.setVerticalScrollBarEnabled(true);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);

        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    /** 构造拍照 Intent，失败返回 null（不影响相册选图） */
    private Intent buildCameraIntent() {
        try {
            File dir = new File(getCacheDir(), "attach");
            if (!dir.exists() && !dir.mkdirs()) {
                return null;
            }
            File photo = new File(dir, "attach_" + System.currentTimeMillis() + ".jpg");
            cameraImageUri = FileProvider.getUriForFile(
                    this, getPackageName() + ".fileprovider", photo);

            Intent capture = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            capture.putExtra(MediaStore.EXTRA_OUTPUT, cameraImageUri);
            capture.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            return capture;
        } catch (Exception e) {
            cameraImageUri = null;
            return null;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_FILE_CHOOSER) {
            if (filePathCallback == null) {
                super.onActivityResult(requestCode, resultCode, data);
                return;
            }
            Uri[] results = null;
            if (resultCode == RESULT_OK) {
                if (data == null) {
                    // 走的是拍照分支，result 通过 EXTRA_OUTPUT 落盘
                    if (cameraImageUri != null) {
                        results = new Uri[]{cameraImageUri};
                    }
                } else if (data.getClipData() != null) {
                    int count = data.getClipData().getItemCount();
                    results = new Uri[count];
                    for (int i = 0; i < count; i++) {
                        results[i] = data.getClipData().getItemAt(i).getUri();
                    }
                } else if (data.getData() != null) {
                    results = new Uri[]{data.getData()};
                } else if (cameraImageUri != null) {
                    results = new Uri[]{cameraImageUri};
                }
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
            cameraImageUri = null;
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onBackPressed() {
        // 页面里若有弹窗/大图查看，优先关掉
        if (webView != null) {
            webView.evaluateJavascript(
                    "(function(){"
                            + "var v=document.getElementById('imgViewer');"
                            + "if(v && getComputedStyle(v).display!=='none'){closeViewer();return 'viewer';}"
                            + "var m=document.getElementById('detailModal');"
                            + "if(m && getComputedStyle(m).display!=='none'){closeModal();return 'modal';}"
                            + "return 'none';})()",
                    value -> {
                        if (value != null && !value.contains("none")) {
                            // 已被页面消费，不再处理返回
                        } else if (webView.canGoBack()) {
                            webView.goBack();
                        } else {
                            finish();
                        }
                    });
            return;
        }
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (filePathCallback != null) {
            filePathCallback.onReceiveValue(null);
            filePathCallback = null;
        }
        if (webView != null) {
            webView.setWebChromeClient(null);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
